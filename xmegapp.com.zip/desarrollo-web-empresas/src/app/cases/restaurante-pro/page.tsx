import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, CheckCircle, ExternalLink, Globe, Users, TrendingUp } from "lucide-react";
import Link from "next/link";

export default function RestauranteProCase() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Navigation */}
      <nav className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/" className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors">
              <ArrowLeft className="h-5 w-5" />
              <span>Volver al Portfolio</span>
            </Link>
            <div className="flex items-center space-x-2">
              <span className="text-xl font-bold text-gray-900">WebDev Pro</span>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-20 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <Badge className="mb-4 bg-green-100 text-green-800">E-commerce</Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            RestaurantePro
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Sistema de pedidos online que revolucionó las ventas de un restaurante local,
            aumentando sus ingresos en un 150% durante los primeros 3 meses.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-lg px-8 py-6">
              <ExternalLink className="mr-2 h-5 w-5" />
              Ver Demo en Vivo
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-6">
              Solicitar Proyecto Similar
            </Button>
          </div>
        </div>
      </section>

      {/* Project Overview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">El Desafío</h2>
              <p className="text-gray-600 mb-6">
                El restaurante "El Buen Sabor" enfrentaba una crisis durante la pandemia. Sus ventas presenciales
                habían caído un 70% y necesitaban urgentemente una solución para ofrecer pedidos online y delivery.
              </p>
              <p className="text-gray-600 mb-8">
                Requerían un sistema completo que incluyera catálogo de productos, carrito de compras,
                integración con pagos online y un panel administrativo para gestionar pedidos en tiempo real.
              </p>

              <h3 className="text-2xl font-bold text-gray-900 mb-4">La Solución</h3>
              <ul className="space-y-3">
                {[
                  "Plataforma e-commerce personalizada con diseño responsive",
                  "Integración con PayPal para pagos seguros online",
                  "Sistema de gestión de inventario en tiempo real",
                  "Panel administrativo para seguimiento de pedidos",
                  "Notificaciones automáticas por WhatsApp",
                  "Optimización SEO para búsquedas locales"
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
                    <span className="text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-purple-50 p-8 rounded-2xl">
              <div className="h-64 bg-gradient-to-br from-blue-400 to-purple-500 rounded-lg mb-6 flex items-center justify-center">
                <Globe className="h-24 w-24 text-white" />
              </div>
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Captura de Pantalla</h4>
              <p className="text-gray-600 text-sm">
                Vista de la página principal del sistema de pedidos con catálogo de productos y carrito de compras.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Technology Stack */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Tecnologías Utilizadas</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Stack tecnológico moderno para garantizar performance, seguridad y escalabilidad
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-xl">Frontend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Badge variant="outline" className="mr-2">React</Badge>
                  <Badge variant="outline" className="mr-2">TypeScript</Badge>
                  <Badge variant="outline" className="mr-2">Tailwind CSS</Badge>
                  <Badge variant="outline" className="mr-2">Next.js</Badge>
                </div>
                <p className="text-sm text-gray-600 mt-4">
                  Interfaz de usuario rápida y responsive
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-xl">Backend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Badge variant="outline" className="mr-2">Node.js</Badge>
                  <Badge variant="outline" className="mr-2">Express</Badge>
                  <Badge variant="outline" className="mr-2">MongoDB</Badge>
                  <Badge variant="outline" className="mr-2">JWT Auth</Badge>
                </div>
                <p className="text-sm text-gray-600 mt-4">
                  API robusta para gestión de datos
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-xl">Integraciones</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Badge variant="outline" className="mr-2">PayPal API</Badge>
                  <Badge variant="outline" className="mr-2">WhatsApp Business</Badge>
                  <Badge variant="outline" className="mr-2">Google Maps</Badge>
                  <Badge variant="outline" className="mr-2">Cloudinary</Badge>
                </div>
                <p className="text-sm text-gray-600 mt-4">
                  Servicios externos para funcionalidad completa
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Results */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Resultados Impresionantes</h2>
            <p className="text-xl text-blue-100 max-w-2xl mx-auto">
              Los números hablan por sí solos sobre el éxito del proyecto
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <TrendingUp className="h-12 w-12 mx-auto mb-4 text-blue-200" />
              <div className="text-4xl font-bold mb-2">150%</div>
              <div className="text-blue-100">Aumento en ventas</div>
            </div>
            <div>
              <Users className="h-12 w-12 mx-auto mb-4 text-blue-200" />
              <div className="text-4xl font-bold mb-2">300+</div>
              <div className="text-blue-100">Clientes nuevos</div>
            </div>
            <div>
              <CheckCircle className="h-12 w-12 mx-auto mb-4 text-blue-200" />
              <div className="text-4xl font-bold mb-2">98%</div>
              <div className="text-blue-100">Satisfacción cliente</div>
            </div>
            <div>
              <Globe className="h-12 w-12 mx-auto mb-4 text-blue-200" />
              <div className="text-4xl font-bold mb-2">2.3s</div>
              <div className="text-blue-100">Tiempo de carga</div>
            </div>
          </div>
        </div>
      </section>

      {/* Client Testimonial */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Lo que dice nuestro cliente</h2>
          <Card className="p-8">
            <CardContent className="pt-6">
              <div className="text-2xl text-gray-600 mb-6 italic">
                "WebDev Pro salvó mi restaurante. En plena pandemia pensé que tendría que cerrar,
                pero gracias a su plataforma de pedidos online no solo sobrevivimos, sino que ahora
                vendemos más que antes. El sistema es súper fácil de usar y mis clientes lo aman."
              </div>
              <div className="flex items-center justify-center space-x-4">
                <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                  MR
                </div>
                <div className="text-left">
                  <div className="font-semibold text-gray-900">María Rodríguez</div>
                  <div className="text-gray-600">Propietaria - Restaurante El Buen Sabor</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            ¿Quieres resultados similares para tu negocio?
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Podemos desarrollar una solución personalizada que impulse las ventas de tu restaurante o negocio.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-lg px-8 py-6">
              Solicitar Consulta Gratuita
            </Button>
            <Link href="/#portfolio">
              <Button variant="outline" size="lg" className="text-lg px-8 py-6">
                Ver Más Casos de Éxito
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
