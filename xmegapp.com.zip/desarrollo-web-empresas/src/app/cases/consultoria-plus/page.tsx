import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, CheckCircle, ExternalLink, BarChart3, Users, Clock, Database } from "lucide-react";
import Link from "next/link";

export default function ConsultoriaPlusCase() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Navigation */}
      <nav className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/" className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors">
              <ArrowLeft className="h-5 w-5" />
              <span>Volver al Portfolio</span>
            </Link>
            <div className="flex items-center space-x-2">
              <span className="text-xl font-bold text-gray-900">WebDev Pro</span>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-20 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <Badge className="mb-4 bg-purple-100 text-purple-800">Sistema CRM</Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            ConsultoríaPlus
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            CRM personalizado que transformó la gestión de clientes de una consultoría empresarial,
            mejorando la eficiencia operativa en un 80% y duplicando la tasa de conversión.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-lg px-8 py-6">
              <ExternalLink className="mr-2 h-5 w-5" />
              Ver Demo del Sistema
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-6">
              Solicitar CRM Similar
            </Button>
          </div>
        </div>
      </section>

      {/* Project Overview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">El Problema</h2>
              <p className="text-gray-600 mb-6">
                "Consultoría Empresarial López" manejaba más de 200 clientes utilizando hojas de Excel dispersas
                y documentos físicos. Esto causaba pérdida de información, seguimiento deficiente de oportunidades
                y una experiencia inconsistente para los clientes.
              </p>
              <p className="text-gray-600 mb-8">
                Necesitaban un sistema centralizado que les permitiera gestionar leads, clientes, proyectos,
                facturación y reportes de manera integrada y eficiente.
              </p>

              <h3 className="text-2xl font-bold text-gray-900 mb-4">Nuestra Implementación</h3>
              <ul className="space-y-3">
                {[
                  "Dashboard ejecutivo con métricas en tiempo real",
                  "Gestión completa del pipeline de ventas",
                  "Sistema de seguimiento de proyectos y tareas",
                  "Automatización de emails y recordatorios",
                  "Reportes personalizados y analytics avanzados",
                  "Integración con herramientas de facturación",
                  "Aplicación móvil para gestión desde cualquier lugar"
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
                    <span className="text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-blue-50 p-8 rounded-2xl">
              <div className="h-64 bg-gradient-to-br from-purple-400 to-blue-500 rounded-lg mb-6 flex items-center justify-center">
                <BarChart3 className="h-24 w-24 text-white" />
              </div>
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Dashboard Principal</h4>
              <p className="text-gray-600 text-sm">
                Vista del dashboard ejecutivo con métricas de ventas, pipeline y rendimiento del equipo.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Key Features */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Funcionalidades Clave</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Sistema completo diseñado específicamente para las necesidades de consultoría empresarial
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="h-full">
              <CardHeader>
                <Users className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Gestión de Contactos</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Base de datos centralizada con historial completo de interacciones,
                  segmentación avanzada y perfiles detallados de clientes.
                </p>
              </CardContent>
            </Card>

            <Card className="h-full">
              <CardHeader>
                <BarChart3 className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Pipeline de Ventas</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Visualización clara del embudo de ventas con etapas personalizadas,
                  probabilidades de cierre y seguimiento automatizado.
                </p>
              </CardContent>
            </Card>

            <Card className="h-full">
              <CardHeader>
                <Clock className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Gestión de Proyectos</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Control de tiempo, asignación de recursos, seguimiento de hitos
                  y colaboración en tiempo real entre equipos.
                </p>
              </CardContent>
            </Card>

            <Card className="h-full">
              <CardHeader>
                <Database className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Reportes y Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Dashboards personalizables con KPIs específicos, reportes automáticos
                  y análisis predictivo de tendencias.
                </p>
              </CardContent>
            </Card>

            <Card className="h-full">
              <CardHeader>
                <CheckCircle className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Automatización</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Workflows automáticos para seguimiento, notificaciones inteligentes
                  y recordatorios basados en comportamiento del cliente.
                </p>
              </CardContent>
            </Card>

            <Card className="h-full">
              <CardHeader>
                <ExternalLink className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Integraciones</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Conexión con herramientas existentes: email, calendario,
                  facturación y plataformas de comunicación.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Technology Stack */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Arquitectura Tecnológica</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Stack empresarial robusto para garantizar seguridad, escalabilidad y performance
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-xl">Frontend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Badge variant="outline" className="mr-2">Next.js</Badge>
                  <Badge variant="outline" className="mr-2">TypeScript</Badge>
                  <Badge variant="outline" className="mr-2">React Query</Badge>
                  <Badge variant="outline" className="mr-2">Chart.js</Badge>
                </div>
                <p className="text-sm text-gray-600 mt-4">
                  Interfaz intuitiva y responsive con dashboards interactivos
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-xl">Backend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Badge variant="outline" className="mr-2">PostgreSQL</Badge>
                  <Badge variant="outline" className="mr-2">Prisma ORM</Badge>
                  <Badge variant="outline" className="mr-2">API REST</Badge>
                  <Badge variant="outline" className="mr-2">Auth0</Badge>
                </div>
                <p className="text-sm text-gray-600 mt-4">
                  Base de datos relacional con seguridad empresarial
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-xl">Infraestructura</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Badge variant="outline" className="mr-2">AWS</Badge>
                  <Badge variant="outline" className="mr-2">Docker</Badge>
                  <Badge variant="outline" className="mr-2">Redis Cache</Badge>
                  <Badge variant="outline" className="mr-2">CloudWatch</Badge>
                </div>
                <p className="text-sm text-gray-600 mt-4">
                  Infraestructura escalable con monitoreo en tiempo real
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Results */}
      <section className="py-16 bg-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Impacto Medible</h2>
            <p className="text-xl text-purple-100 max-w-2xl mx-auto">
              Transformación digital que se reflejó directamente en los resultados del negocio
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <BarChart3 className="h-12 w-12 mx-auto mb-4 text-purple-200" />
              <div className="text-4xl font-bold mb-2">80%</div>
              <div className="text-purple-100">Mejora eficiencia</div>
            </div>
            <div>
              <Users className="h-12 w-12 mx-auto mb-4 text-purple-200" />
              <div className="text-4xl font-bold mb-2">2x</div>
              <div className="text-purple-100">Tasa conversión</div>
            </div>
            <div>
              <Clock className="h-12 w-12 mx-auto mb-4 text-purple-200" />
              <div className="text-4xl font-bold mb-2">60%</div>
              <div className="text-purple-100">Menos tiempo admin</div>
            </div>
            <div>
              <CheckCircle className="h-12 w-12 mx-auto mb-4 text-purple-200" />
              <div className="text-4xl font-bold mb-2">95%</div>
              <div className="text-purple-100">Adopción del equipo</div>
            </div>
          </div>
        </div>
      </section>

      {/* Client Testimonial */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Testimonio del Cliente</h2>
          <Card className="p-8">
            <CardContent className="pt-6">
              <div className="text-2xl text-gray-600 mb-6 italic">
                "El CRM que desarrolló WebDev Pro revolucionó nuestra forma de trabajar. Antes perdíamos
                oportunidades por falta de seguimiento, ahora tenemos control total de nuestro pipeline.
                La productividad de mi equipo se duplicó y la satisfacción de nuestros clientes mejoró notablemente."
              </div>
              <div className="flex items-center justify-center space-x-4">
                <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                  CL
                </div>
                <div className="text-left">
                  <div className="font-semibold text-gray-900">Carlos López</div>
                  <div className="text-gray-600">Director General - Consultoría Empresarial López</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            ¿Necesitas un CRM personalizado para tu empresa?
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Desarrollamos sistemas de gestión que se adaptan perfectamente a tus procesos de negocio.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-lg px-8 py-6">
              Agendar Demostración
            </Button>
            <Link href="/#portfolio">
              <Button variant="outline" size="lg" className="text-lg px-8 py-6">
                Explorar Más Proyectos
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
