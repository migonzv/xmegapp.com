"use client";
import { useI18N } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Code,
  Smartphone,
  Zap,
  Users,
  CheckCircle,
  Star,
  ArrowRight,
  Globe,
  Palette,
  Database,
  Shield,
  MessageCircle,
  Mail,
  Phone,
  DollarSign,
  Calendar,
  Monitor
} from "lucide-react";

export default function Home() {
  const { t, locale, setLocale } = useI18N();
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Navigation */}
      <nav className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <Code className="h-8 w-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-900">{t.brand}</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#servicios" className="text-gray-600 hover:text-blue-600 transition-colors">{t.nav.servicios}</a>
              <a href="#nosotros" className="text-gray-600 hover:text-blue-600 transition-colors">{t.nav.nosotros}</a>
              <a href="#portfolio" className="text-gray-600 hover:text-blue-600 transition-colors">{t.nav.portfolio}</a>
              <a href="#precios" className="text-gray-600 hover:text-blue-600 transition-colors">{t.nav.precios}</a>
              <a href="#contacto" className="text-gray-600 hover:text-blue-600 transition-colors">{t.nav.contacto}</a>
              {/* Nuevo botón de idioma */}
              <button
                onClick={() => setLocale(locale === 'es' ? 'en' : 'es')}
                className="ml-2 px-4 py-2 rounded-md bg-blue-600 shadow hover:bg-blue-700 text-white font-bold transition-all"
                aria-label={locale === "es" ? "Ver en inglés" : "See in Spanish"}
                type="button"
              >
                {locale === "es" ? "Español" : "English"}
              </button>
              <Button>{t.nav.cotizacion}</Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-20 pb-32 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 animate-fade-in animate-delay-200">
            {t.hero.headline1}
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent animate-pulse">
              {t.hero.headline2}
            </span>
            {t.hero.headline3}
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto animate-fade-in animate-delay-500">
            {t.hero.description}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in animate-delay-700">
            <Button size="lg" className="text-lg px-8 py-6 transform hover:scale-105 transition-all duration-300">
              {t.hero.comenzar}
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-6 transform hover:scale-105 transition-all duration-300">
              {t.hero.ver_portfolio}
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="servicios" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Nuestros Servicios
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Ofrecemos soluciones completas de desarrollo web adaptadas a las necesidades específicas de tu negocio
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Globe,
                title: "Sitios Web Corporativos",
                description: "Páginas web profesionales que representan tu marca y generan confianza en tus clientes",
                features: ["Diseño responsive", "SEO optimizado", "Carga rápida"]
              },
              {
                icon: Smartphone,
                title: "Aplicaciones Web",
                description: "Sistemas web personalizados para gestionar tu negocio de manera eficiente",
                features: ["Panel de administración", "Gestión de usuarios", "Reportes en tiempo real"]
              },
              {
                icon: Palette,
                title: "E-commerce",
                description: "Tiendas online completas para vender tus productos o servicios en internet",
                features: ["Carrito de compras", "Pasarelas de pago", "Gestión de inventario"]
              },
              {
                icon: Database,
                title: "Sistemas de Gestión",
                description: "CRM y ERP personalizados para optimizar los procesos de tu empresa",
                features: ["Automatización", "Integración APIs", "Base de datos segura"]
              },
              {
                icon: Shield,
                title: "Mantenimiento Web",
                description: "Actualizaciones, respaldos y soporte técnico continuo para tu aplicación",
                features: ["Respaldos automáticos", "Actualizaciones de seguridad", "Monitoreo 24/7"]
              },
              {
                icon: Zap,
                title: "Optimización",
                description: "Mejoramos el rendimiento y velocidad de aplicaciones web existentes",
                features: ["Análisis de rendimiento", "Optimización de código", "Mejora de UX"]
              }
            ].map((service, index) => (
              <Card key={index} className="h-full hover:shadow-lg transition-shadow">
                <CardHeader>
                  <service.icon className="h-12 w-12 text-blue-600 mb-4" />
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <CardDescription className="text-gray-600">
                    {service.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm text-gray-600">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section id="nosotros" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-center">
            {/* Columna 1: Por qué elegirnos */}
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                ¿Por qué elegir WebDev Pro?
              </h2>
              <p className="text-lg text-gray-600 mb-8">
                Somos un equipo especializado en ayudar a pequeñas empresas y emprendedores
                a crecer en el mundo digital con soluciones web profesionales y asequibles.
              </p>
              <div className="space-y-6">
                {[
                  {
                    icon: Users,
                    title: "Enfoque Personalizado",
                    description: "Cada proyecto es único. Analizamos tu negocio para crear la solución perfecta."
                  },
                  {
                    icon: Zap,
                    title: "Desarrollo Ágil",
                    description: "Metodología ágil que permite entregas rápidas y comunicación constante."
                  },
                  {
                    icon: Shield,
                    title: "Soporte Continuo",
                    description: "No te dejamos solo después del lanzamiento. Soporte técnico y mantenimiento incluido."
                  }
                ].map((item, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="bg-blue-100 p-3 rounded-lg">
                      <item.icon className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">{item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Columna 2: Imágenes reales multi-dispositivo */}
            <div>
              <h3 className="text-xl font-bold text-gray-900 text-center mb-6">Aplicaciones Responsivas en Todos los Dispositivos</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <img src="https://ugc.same-assets.com/47xnrrvBpFroxQYJtqk4-uic1VbGIvTU.jpeg" alt="TV app restaurante" className="w-full rounded-lg shadow" />
                  <div className="text-xs text-gray-500 text-center mt-2">Smart TV</div>
                </div>
                <div>
                  <img src="https://ugc.same-assets.com/SI1F7qKZQu3hAL5j4qXtNSgm2Rc-C9_f.jpeg" alt="Laptop app restaurante" className="w-full rounded-lg shadow" />
                  <div className="text-xs text-gray-500 text-center mt-2">Laptop</div>
                </div>
                <div>
                  <img src="https://ugc.same-assets.com/cmErOoKn-tudVWLW0k7SnbANoROZV6RC.jpeg" alt="Tablet app restaurante" className="w-full rounded-lg shadow" />
                  <div className="text-xs text-gray-500 text-center mt-2">Tablet</div>
                </div>
                <div>
                  <img src="https://ugc.same-assets.com/EDPYXqXIAtxRNzJrUMSRONP7PpjEC1sS.jpeg" alt="Smartphone app restaurante" className="w-full rounded-lg shadow" />
                  <div className="text-xs text-gray-500 text-center mt-2">Móvil</div>
                </div>
              </div>
            </div>

            {/* Columna 3: Nuestro Proceso */}
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-8 rounded-2xl">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Nuestro Proceso</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full border-collapse rounded-lg shadow bg-white text-left">
                  <thead>
                    <tr className="bg-blue-100">
                      <th className="py-3 px-4 border-b border-blue-200 font-semibold">Fase</th>
                      <th className="py-3 px-4 border-b border-blue-200 font-semibold">Descripción</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="odd:bg-blue-50 even:bg-purple-50 border-b border-blue-100">
                      <td className="py-2 px-4 font-medium text-blue-800">1. Consulta Inicial</td>
                      <td className="py-2 px-4 text-gray-700">Reunión gratuita para conocer tus necesidades y visión.</td>
                    </tr>
                    <tr className="odd:bg-blue-50 even:bg-purple-50 border-b border-blue-100">
                      <td className="py-2 px-4 font-medium text-blue-800">2. Análisis de Requerimientos</td>
                      <td className="py-2 px-4 text-gray-700">Definición detallada de funcionalidades y alcance del proyecto.</td>
                    </tr>
                    <tr className="odd:bg-blue-50 even:bg-purple-50 border-b border-blue-100">
                      <td className="py-2 px-4 font-medium text-blue-800">3. Propuesta y Cotización</td>
                      <td className="py-2 px-4 text-gray-700">Presentación de propuesta personalizada y cotización clara.</td>
                    </tr>
                    <tr className="odd:bg-blue-50 even:bg-purple-50 border-b border-blue-100">
                      <td className="py-2 px-4 font-medium text-blue-800">4. Desarrollo y Pruebas</td>
                      <td className="py-2 px-4 text-gray-700">Diseño, programación y pruebas en colaboración contigo.</td>
                    </tr>
                    <tr className="odd:bg-blue-50 even:bg-purple-50 border-b border-blue-100">
                      <td className="py-2 px-4 font-medium text-blue-800">5. Lanzamiento y Capacitación</td>
                      <td className="py-2 px-4 text-gray-700">Publicación de la app y capacitación para asegurar un uso óptimo.</td>
                    </tr>
                    <tr className="odd:bg-blue-50 even:bg-purple-50">
                      <td className="py-2 px-4 font-medium text-blue-800">6. Soporte Continuo</td>
                      <td className="py-2 px-4 text-gray-700">Acompañamiento, mantenimiento y mejoras según evolución.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <Button className="w-full mt-6">
                Comenzar Ahora
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Casos de Éxito
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Conoce algunos de los proyectos que hemos desarrollado para nuestros clientes
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                title: "RestaurantePro",
                category: "E-commerce",
                description: "Sistema de pedidos online para restaurante local, aumentó ventas en 150%",
                tags: ["React", "Node.js", "PayPal"]
              },
              {
                title: "ConsultoríaPlus",
                category: "Sistema CRM",
                description: "CRM personalizado para consultora, mejoró gestión de clientes en 80%",
                tags: ["Next.js", "PostgreSQL", "API REST"]
              },
              {
                title: "TiendaModa",
                category: "E-commerce",
                description: "Tienda online de ropa, integración con redes sociales y WhatsApp",
                tags: ["Shopify", "React", "Stripe"]
              },
              {
                title: "ClínicaSalud",
                category: "Sistema Médico",
                description: "Portal médico con sistema de citas online, redujo tiempo de espera en 60%",
                tags: ["Vue.js", "MySQL", "Calendar API"]
              }
            ].map((project, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="h-48 bg-gradient-to-br from-blue-400 to-purple-500"></div>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">{project.title}</CardTitle>
                    <Badge variant="secondary">{project.category}</Badge>
                  </div>
                  <CardDescription>{project.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="precios" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Paquetes y Precios
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Inversión transparente para el desarrollo de tu proyecto y planes flexibles de mantenimiento
            </p>
          </div>

          {/* Development Cost */}
          <div className="mb-16">
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200">
              <CardHeader className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="bg-blue-100 p-4 rounded-full">
                    <DollarSign className="h-8 w-8 text-blue-600" />
                  </div>
                </div>
                <CardTitle className="text-2xl md:text-3xl font-bold text-gray-900">
                  Desarrollo Inicial del Proyecto
                </CardTitle>
                <CardDescription className="text-lg">
                  Inversión única para el desarrollo completo de tu aplicación web
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-blue-600 mb-4">
                  $250 - $1,000
                </div>
                <p className="text-gray-600 mb-6">
                  El costo varía según la complejidad del proyecto, funcionalidades requeridas y tiempo de desarrollo
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600 mb-2">$250 - $400</div>
                    <div className="font-semibold text-gray-900 mb-2">Proyectos Básicos</div>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• Sitios web informativos</li>
                      <li>• Landing pages</li>
                      <li>• Portafolios personales</li>
                    </ul>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600 mb-2">$400 - $700</div>
                    <div className="font-semibold text-gray-900 mb-2">Proyectos Intermedios</div>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• E-commerce básico</li>
                      <li>• Sistemas de gestión</li>
                      <li>• Aplicaciones con BD</li>
                    </ul>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600 mb-2">$700 - $1,000</div>
                    <div className="font-semibold text-gray-900 mb-2">Proyectos Avanzados</div>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• CRM/ERP personalizados</li>
                      <li>• E-commerce complejo</li>
                      <li>• Integraciones múltiples</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Maintenance Plans */}
          <div>
            <div className="text-center mb-12">
              <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
                Planes de Mantenimiento y Soporte
              </h3>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Elige el plan que mejor se adapte a tus necesidades. Incluye actualizaciones, respaldos, soporte técnico y monitoreo.
              </p>
            </div>

            <Tabs defaultValue="anual" className="w-full">
              <TabsList className="grid w-full grid-cols-4 max-w-2xl mx-auto mb-8">
                <TabsTrigger value="anual">Anual</TabsTrigger>
                <TabsTrigger value="semestral">Semestral</TabsTrigger>
                <TabsTrigger value="trimestral">Trimestral</TabsTrigger>
                <TabsTrigger value="mensual">Mensual</TabsTrigger>
              </TabsList>

              {/* Monthly Plan */}
              <TabsContent value="mensual">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { devices: 1, price: 5, popular: false },
                    { devices: 2, price: 8, popular: false },
                    { devices: 3, price: 10, popular: false },
                    { devices: 4, price: 15, popular: true }
                  ].map((plan, index) => (
                    <Card key={index} className={`relative ${plan.popular ? 'border-2 border-blue-500 shadow-lg' : ''}`}>
                      {plan.popular && (
                        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                          <Badge className="bg-blue-500 text-white px-3 py-1">Más Popular</Badge>
                        </div>
                      )}
                      <CardHeader className="text-center">
                        <Monitor className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                        <CardTitle className="text-xl">{plan.devices} Dispositivo{plan.devices > 1 ? 's' : ''}</CardTitle>
                        <div className="text-3xl font-bold text-blue-600">${plan.price}</div>
                        <div className="text-sm text-gray-600">por mes</div>
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          {plan.devices > 1 ? "Dispositivos incluidos" : "Dispositivo incluido"}
                        </Badge>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Respaldos automáticos
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Actualizaciones de seguridad
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Soporte técnico
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Monitoreo 24/7
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            {plan.devices} dispositivo{plan.devices > 1 ? 's' : ''} incluido{plan.devices > 1 ? 's' : ''}
                          </li>
                        </ul>
                        <Button className="w-full mt-6" variant={plan.popular ? "default" : "outline"}>
                          Seleccionar Plan
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Quarterly Plan */}
              <TabsContent value="trimestral">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { devices: 1, price: 10, popular: false, savings: "33%" },
                    { devices: 2, price: 15, popular: false, savings: "38%" },
                    { devices: 3, price: 20, popular: false, savings: "33%" },
                    { devices: 4, price: 25, popular: true, savings: "44%" }
                  ].map((plan, index) => (
                    <Card key={index} className={`relative ${plan.popular ? 'border-2 border-blue-500 shadow-lg' : ''}`}>
                      {plan.popular && (
                        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                          <Badge className="bg-blue-500 text-white px-3 py-1">Más Popular</Badge>
                        </div>
                      )}
                      <CardHeader className="text-center">
                        <Calendar className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                        <CardTitle className="text-xl">{plan.devices} Dispositivo{plan.devices > 1 ? 's' : ''}</CardTitle>
                        <div className="text-3xl font-bold text-blue-600">${plan.price}</div>
                        <div className="text-sm text-gray-600">por 3 meses</div>
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          Ahorra {plan.savings}
                        </Badge>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Respaldos automáticos
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Actualizaciones de seguridad
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Soporte técnico prioritario
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Monitoreo 24/7
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            {plan.devices} dispositivo{plan.devices > 1 ? 's' : ''} incluido{plan.devices > 1 ? 's' : ''}
                          </li>
                        </ul>
                        <Button className="w-full mt-6" variant={plan.popular ? "default" : "outline"}>
                          Seleccionar Plan
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Semester Plan */}
              <TabsContent value="semestral">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { devices: 1, price: 20, popular: false, savings: "33%" },
                    { devices: 2, price: 30, popular: false, savings: "38%" },
                    { devices: 3, price: 40, popular: false, savings: "33%" },
                    { devices: 4, price: 50, popular: true, savings: "44%" }
                  ].map((plan, index) => (
                    <Card key={index} className={`relative ${plan.popular ? 'border-2 border-blue-500 shadow-lg' : ''}`}>
                      {plan.popular && (
                        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                          <Badge className="bg-blue-500 text-white px-3 py-1">Más Popular</Badge>
                        </div>
                      )}
                      <CardHeader className="text-center">
                        <Calendar className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                        <CardTitle className="text-xl">{plan.devices} Dispositivo{plan.devices > 1 ? 's' : ''}</CardTitle>
                        <div className="text-3xl font-bold text-blue-600">${plan.price}</div>
                        <div className="text-sm text-gray-600">por 6 meses</div>
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          Ahorra {plan.savings}
                        </Badge>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Respaldos automáticos
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Actualizaciones de seguridad
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Soporte técnico prioritario
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Monitoreo 24/7
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Reportes mensuales
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            {plan.devices} dispositivo{plan.devices > 1 ? 's' : ''} incluido{plan.devices > 1 ? 's' : ''}
                          </li>
                        </ul>
                        <Button className="w-full mt-6" variant={plan.popular ? "default" : "outline"}>
                          Seleccionar Plan
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Annual Plan */}
              <TabsContent value="anual">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { devices: 1, price: 35, popular: false, savings: "42%" },
                    { devices: 2, price: 55, popular: false, savings: "43%" },
                    { devices: 3, price: 75, popular: false, savings: "38%" },
                    { devices: 4, price: 100, popular: true, savings: "44%" }
                  ].map((plan, index) => (
                    <Card key={index} className={`relative ${plan.popular ? 'border-2 border-blue-500 shadow-lg' : ''}`}>
                      {plan.popular && (
                        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                          <Badge className="bg-blue-500 text-white px-3 py-1">Más Popular</Badge>
                        </div>
                      )}
                      <CardHeader className="text-center">
                        <Star className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
                        <CardTitle className="text-xl">{plan.devices} Dispositivo{plan.devices > 1 ? 's' : ''}</CardTitle>
                        <div className="text-3xl font-bold text-blue-600">${plan.price}</div>
                        <div className="text-sm text-gray-600">por año</div>
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          Ahorra {plan.savings}
                        </Badge>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Respaldos automáticos
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Actualizaciones de seguridad
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Soporte técnico VIP
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Monitoreo 24/7
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Reportes mensuales
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            Consultoría gratuita
                          </li>
                          <li className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            {plan.devices} dispositivo{plan.devices > 1 ? 's' : ''} incluido{plan.devices > 1 ? 's' : ''}
                          </li>
                        </ul>
                        <Button className="w-full mt-6" variant={plan.popular ? "default" : "outline"}>
                          Seleccionar Plan
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>

            <div className="mt-12 text-center">
              <div className="bg-blue-50 rounded-lg p-6 max-w-4xl mx-auto">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">¿Qué incluye cada dispositivo?</h4>
                <p className="text-gray-600">
                  Cada dispositivo incluye compatibilidad completa (desktop, tablet, móvil), optimización de rendimiento,
                  y soporte técnico dedicado. Ideal para empresas con múltiples sucursales o equipos de trabajo.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Lo que dicen nuestros clientes
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                name: "María González",
                company: "Boutique Elegancia",
                content: "WebDev Pro transformó completamente mi negocio. La tienda online que desarrollaron me permitió triplicar mis ventas en solo 3 meses.",
                rating: 5
              },
              {
                name: "Carlos Rodríguez",
                company: "Consultoría Empresarial",
                content: "El CRM personalizado que crearon para mi consultora es exactamente lo que necesitaba. Ahora gestiono mis clientes de manera mucho más eficiente.",
                rating: 5
              },
              {
                name: "Ana Martínez",
                company: "Restaurante El Buen Sabor",
                content: "El sistema de pedidos online ha sido un éxito total. Mis clientes pueden ordenar fácilmente y yo he aumentado mis ventas significativamente.",
                rating: 5
              },
              {
                name: "Dr. Luis Fernández",
                company: "ClínicaSalud",
                content: "El portal médico con sistema de citas online revolucionó nuestra atención. Redujimos los tiempos de espera en un 60% y nuestros pacientes están encantados con la facilidad para agendar.",
                rating: 5
              }
            ].map((testimonial, index) => (
              <Card key={index} className="h-full">
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    <Avatar>
                      <AvatarFallback>{testimonial.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                      <p className="text-sm text-gray-600">{testimonial.company}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-600">{testimonial.content}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contacto" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                ¿Listo para comenzar tu proyecto?
              </h2>
              <p className="text-lg text-gray-600 mb-8">
                Contáctanos para una consulta gratuita. Analizaremos tu proyecto y te daremos
                una propuesta personalizada sin compromiso.
              </p>

              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <Phone className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Teléfono</h4>
                    <p className="text-gray-600">+1 (555) 123-4567</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <Mail className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Email</h4>
                    <p className="text-gray-600">contacto@webdevpro.com</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <MessageCircle className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">WhatsApp</h4>
                    <p className="text-gray-600">+1 (555) 987-6543</p>
                  </div>
                </div>
              </div>
            </div>

            <Card className="p-6">
              <CardHeader className="px-0 pt-0">
                <CardTitle>Solicitar Cotización Gratuita</CardTitle>
                <CardDescription>
                  Cuéntanos sobre tu proyecto y te responderemos en menos de 24 horas
                </CardDescription>
              </CardHeader>
              <CardContent className="px-0">
                <form className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input placeholder="Nombre completo" />
                    <Input type="email" placeholder="Email" />
                  </div>
                  <Input placeholder="Empresa" />
                  <Input placeholder="Teléfono" />
                  <Input placeholder="Tipo de proyecto (sitio web, e-commerce, sistema, etc.)" />
                  <Textarea
                    placeholder="Describe tu proyecto y objetivos..."
                    className="min-h-32"
                  />
                  <Button className="w-full" size="lg">
                    Enviar Solicitud
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Code className="h-8 w-8 text-blue-400" />
                <span className="text-xl font-bold">WebDev Pro</span>
              </div>
              <p className="text-gray-400">
                Desarrollamos aplicaciones web personalizadas para emprendedores y pequeñas empresas.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Servicios</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Sitios Web Corporativos</li>
                <li>Aplicaciones Web</li>
                <li>E-commerce</li>
                <li>Sistemas de Gestión</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Empresa</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Sobre Nosotros</li>
                <li>Portfolio</li>
                <li>Testimonios</li>
                <li>Blog</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contacto</h4>
              <ul className="space-y-2 text-gray-400">
                <li>contacto@webdevpro.com</li>
                <li>+1 (555) 123-4567</li>
                <li>WhatsApp: +1 (555) 987-6543</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 WebDev Pro. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
