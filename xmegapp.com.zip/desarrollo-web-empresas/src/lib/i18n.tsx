"use client";
import { type ReactNode, createContext, useContext, useState } from "react";

const translations = {
  es: {
    brand: "WebDev Pro",
    nav: {
      servicios: "Servicios",
      nosotros: "Nosotros",
      portfolio: "Portfolio",
      precios: "Precios",
      contacto: "Contacto",
      cotizacion: "Solicitar Cotización",
    },
    hero: {
      headline1: "Desarrollamos la ",
      headline2: "aplicación web",
      headline3: " que tu negocio necesita",
      description:
        "Ayudamos a emprendedores y pequeñas empresas a digitalizar sus negocios con aplicaciones web personalizadas, modernas y escalables.",
      comenzar: "Comenzar Proyecto",
      ver_portfolio: "Ver Portfolio"
    },
    // ...[otros textos, evitando repetir demasiado para brevedad aquí]
  },
  en: {
    brand: "WebDev Pro",
    nav: {
      servicios: "Services",
      nosotros: "About Us",
      portfolio: "Portfolio",
      precios: "Pricing",
      contacto: "Contact",
      cotizacion: "Get a Quote",
    },
    hero: {
      headline1: "We develop the ",
      headline2: "web application",
      headline3: " your business needs",
      description:
        "We help entrepreneurs and small businesses go digital with tailored, modern and scalable web applications.",
      comenzar: "Start Project",
      ver_portfolio: "See Portfolio"
    },
    // ...[otros textos]
  },
};

export type Locale = "es" | "en";

const I18NContext = createContext<{
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: typeof translations["en"];
}>({
  locale: "es",
  setLocale: () => {},
  t: translations["es"],
});

export const I18NProvider = ({ children } : { children: ReactNode }) => {
  const [locale, setLocale] = useState<Locale>("es");
  const t = translations[locale];
  return (
    <I18NContext.Provider value={{ locale, setLocale, t }}>
      {children}
    </I18NContext.Provider>
  );
};

export const useI18N = () => useContext(I18NContext);

// Cuando amplíes los textos del sitio, actualiza las claves aquí también.
